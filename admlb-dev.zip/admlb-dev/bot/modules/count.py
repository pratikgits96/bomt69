from time import time
from telegram.ext import CommandHandler

from bot import dispatcher, LOGGER
from bot.helper.mirror_utils.upload_utils.gdriveTools import GoogleDriveHelper
from bot.helper.telegram_helper.message_utils import deleteMessage, sendMessage
from bot.helper.telegram_helper.filters import CustomFilters
from bot.helper.telegram_helper.bot_commands import BotCommands
from bot.helper.ext_utils.bot_utils import is_parser_link, is_gdrive_link, get_readable_time, new_thread
from bot.helper.mirror_utils.download_utils.direct_link_generator import gd_link_generator
from bot.helper.ext_utils.exceptions import DirectDownloadLinkException

@new_thread
def countNode(update, context):
    reply_to = update.message.reply_to_message
    elapsed_time = time()
    parser = False
    link = ''
    if len(context.args) == 1:
        link = context.args[0]
        if update.message.from_user.username:
            tag = f"@{update.message.from_user.username}"
        else:
            tag = update.message.from_user.mention_html(update.message.from_user.first_name)
    if reply_to:
        if len(link) == 0:
            link = reply_to.text.split(maxsplit=1)[0].strip()
        if reply_to.from_user.username:
            tag = f"@{reply_to.from_user.username}"
        else:
            tag = reply_to.from_user.mention_html(reply_to.from_user.first_name)
    if is_parser_link(link):
        parser = sendMessage(f"<b>Processing:</b> <code>{link}</code>", context.bot, update.message)
        try:
            link = gd_link_generator(link)
            deleteMessage(context.bot, parser)
            LOGGER.info(f"Generated gdrive link: {link}")
        except DirectDownloadLinkException as e:
            deleteMessage(context.bot, parser)
            LOGGER.info(str(e))
            if str(e).startswith('ERROR:'):
                return sendMessage(str(e), context.bot, update.message)
    if is_gdrive_link(link):
        msg = sendMessage(f"<b>Counting:</b> <code>{link}</code>", context.bot, update.message)
        gd = GoogleDriveHelper()
        result = gd.count(link)
        deleteMessage(context.bot, msg)
        cc = f"\n\n<b>Elapsed:</b> {get_readable_time(time() - elapsed_time)}"
        cc += f'\n\n<b>cc: </b>{tag}'
        sendMessage(result + cc, context.bot, update.message)
        if parser:
            gd.deletefile(link)
    else:
        sendMessage('Send GDrive, GDToT, HubDrive, AppDrive link along with command or by replying to the link by command', context.bot, update.message)

count_handler = CommandHandler(BotCommands.CountCommand, countNode, filters=CustomFilters.authorized_chat | CustomFilters.authorized_user, run_async=True)
dispatcher.add_handler(count_handler)
